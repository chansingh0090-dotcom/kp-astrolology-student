KP Student App - Android Studio Project

IMPORTANT:
This is an Android WebView wrapper project. The KP calculation/BTR API runs in the
Flask backend from the companion source bundle, not inside the Android APK.

Before building:
1. Deploy the Flask backend (app.py + requirements.txt) to an HTTPS host.
2. Open app/src/main/assets/index.html.
3. Replace https://YOUR-BACKEND-DOMAIN with your real backend HTTPS base URL.
4. Open this folder in Android Studio (Giraffe or newer).
5. Allow Gradle sync and install Android SDK Platform 35 if prompted.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK output: app/build/outputs/apk/debug/app-debug.apk

For release:
Build > Generate Signed Bundle / APK > APK, then create and securely keep your
own signing key. Do not share the private keystore/password.

The debug APK is for testing. A release APK should be signed before distribution.

Language support: Hindi + English toggle is available in the app header. Default language is Hindi; users can switch to English.
