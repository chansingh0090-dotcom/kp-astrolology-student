KP STUDENT APP — MOBILE + COMPUTER EDITION

A) COMPUTER / LAPTOP (Windows, Mac, Linux)
1. Install Python 3.10 or newer.
2. Open terminal in the 'server' folder.
3. Run:
   python -m venv .venv
   Windows: .venv\\Scripts\\activate
   Mac/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   python app.py
4. Open http://127.0.0.1:5000 in Chrome, Edge, Firefox or Safari.
   This is the desktop browser version.

B) MOBILE PHONE
Option 1 — Installable web app (Android/iPhone):
1. Deploy the 'server' folder to an HTTPS host.
2. Open the public HTTPS website in Chrome (Android) or Safari (iPhone).
3. Android: browser menu > Install app / Add to Home screen.
   iPhone: Share > Add to Home Screen.
4. The app shell can open after first visit; calculation/BTR needs the backend online.

Option 2 — Android APK project:
1. Open 'android-studio' folder in Android Studio.
2. Deploy the Flask backend to HTTPS.
3. In android-studio/app/src/main/assets/index.html, replace
   https://YOUR-BACKEND-DOMAIN with your real backend HTTPS base URL.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

C) SAME ACCOUNT / SAME DATA
This bundle currently does not include login or cloud-synced saved charts.
Each browser/device has its own local browser data. Add authentication and database
before using it as a multi-user public service.

IMPORTANT
- The UI is responsive for phone and desktop.
- KP calculation and BTR API run in Python Flask + Swiss Ephemeris.
- PWA shell caching does not make astronomical calculations work offline.
- BTR is a Ruling-Planet matching heuristic and must be validated by a KP practitioner.
- Deploy with HTTPS and a production WSGI server before public use.
