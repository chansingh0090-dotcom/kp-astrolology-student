KP Student App - Local setup

1) Python 3.10+ install karein.
2) Terminal/Command Prompt mein project folder kholein.
3) Run:
   python -m venv .venv
   .venv\Scripts\activate        (Windows)
   source .venv/bin/activate      (Mac/Linux)
   pip install -r requirements.txt
   python app.py
4) Browser mein http://127.0.0.1:5000 kholein.

Features:
- KP Ayanamsa via Swiss Ephemeris
- Planet longitudes, Nakshatra lord, Sub lord
- Placidus 12 cusps and Ascendant
- Ruling Planets list
- Ruling-planet matching based BTR candidate ranking

Important:
BTR ranking is an explicitly disclosed heuristic, not a scientifically or universally validated
method and not a guaranteed birth-time determination. Confirm with a qualified KP astrologer.
For public deployment, use production WSGI server, HTTPS, input validation, rate limits,
and verify Swiss Ephemeris licensing/data-file requirements for your use case.
