from flask import Flask, request, jsonify, send_from_directory
from datetime import datetime, timedelta, timezone
import swisseph as swe

app = Flask(__name__, static_folder="static")
swe.set_sid_mode(swe.SIDM_KRISHNAMURTI)

PLANETS = {
    "Sun": swe.SUN, "Moon": swe.MOON, "Mars": swe.MARS,
    "Mercury": swe.MERCURY, "Jupiter": swe.JUPITER,
    "Venus": swe.VENUS, "Saturn": swe.SATURN,
    "Rahu": swe.TRUE_NODE
}
VIM_ORDER = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"]
VIM_YEARS = {"Ketu":7, "Venus":20, "Sun":6, "Moon":10, "Mars":7,
             "Rahu":18, "Jupiter":16, "Saturn":19, "Mercury":17}
SIGN_LORDS = ["Mars","Venus","Mercury","Moon","Sun","Mercury",
              "Venus","Mars","Jupiter","Saturn","Saturn","Jupiter"]
SIGNS = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo",
         "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"]
NAKSHATRAS = [
 "Ashwini","Bharani","Krittika","Rohini","Mrigashira","Ardra","Punarvasu",
 "Pushya","Ashlesha","Magha","Purva Phalguni","Uttara Phalguni","Hasta",
 "Chitra","Swati","Vishakha","Anuradha","Jyeshtha","Mula","Purva Ashadha",
 "Uttara Ashadha","Shravana","Dhanishta","Shatabhisha","Purva Bhadrapada",
 "Uttara Bhadrapada","Revati"
]
DAY_LORDS = ["Moon","Mars","Mercury","Jupiter","Venus","Saturn","Sun"]
NAK_SIZE = 360.0 / 27.0

def norm(x):
    return x % 360.0

def jd_from_local(value, offset_hours):
    dt = datetime.fromisoformat(value)
    local_tz = timezone(timedelta(hours=float(offset_hours)))
    aware = dt.replace(tzinfo=local_tz)
    utc = aware.astimezone(timezone.utc)
    hour = utc.hour + utc.minute/60 + utc.second/3600 + utc.microsecond/3.6e9
    return swe.julday(utc.year, utc.month, utc.day, hour, swe.GREG_CAL)

def planet_longitudes(jd):
    flags = swe.FLG_SWIEPH | swe.FLG_SIDEREAL | swe.FLG_SPEED
    out = {}
    for name, p in PLANETS.items():
        xx, _ = swe.calc_ut(jd, p, flags)
        out[name] = norm(xx[0])
    out["Ketu"] = norm(out["Rahu"] + 180.0)
    return out

def star_sub(longitude):
    lon = norm(longitude)
    nak_index = int(lon / NAK_SIZE)
    within = lon - nak_index * NAK_SIZE
    star = VIM_ORDER[nak_index % 9]
    cursor = 0.0
    sub = star
    for lord in VIM_ORDER[VIM_ORDER.index(star):] + VIM_ORDER[:VIM_ORDER.index(star)]:
        span = NAK_SIZE * VIM_YEARS[lord] / 120.0
        if within < cursor + span or lord == "Mercury":
            sub = lord
            break
        cursor += span
    return NAKSHATRAS[nak_index], star, sub

def point_details(longitude):
    lon = norm(longitude)
    sign_index = int(lon // 30)
    nak, star, sub = star_sub(lon)
    return {
        "degree": round(lon, 6),
        "sign_number": sign_index + 1,
        "sign": SIGNS[sign_index],
        "sign_lord": SIGN_LORDS[sign_index],
        "nakshatra": nak,
        "star_lord": star,
        "sub_lord": sub
    }

def asc_and_cusps(jd, lat, lon):
    cusps, ascmc = swe.houses_ex(jd, float(lat), float(lon), b'P', swe.FLG_SIDEREAL)
    asc = norm(ascmc[0])
    return asc, [norm(x) for x in cusps[1:13]]

def ruling_planets(jd, lat, lon, tz_offset=0):
    dt = swe.revjul(jd, swe.GREG_CAL)
    # Ruling day lord must use the local civil date at the birth/query location.
    utc_dt = datetime(dt[0], dt[1], dt[2]) + timedelta(hours=dt[3] + float(tz_offset))
    weekday = utc_dt.weekday()  # 0 Monday ... 6 Sunday
    longs = planet_longitudes(jd)
    moon = point_details(longs["Moon"])
    asc, _ = asc_and_cusps(jd, lat, lon)
    asc_d = point_details(asc)
    rows = [
        ("Day Lord", DAY_LORDS[weekday]),
        ("Moon Sign Lord", moon["sign_lord"]),
        ("Moon Star Lord", moon["star_lord"]),
        ("Moon Sub Lord", moon["sub_lord"]),
        ("Ascendant Sign Lord", asc_d["sign_lord"]),
        ("Ascendant Star Lord", asc_d["star_lord"]),
        ("Ascendant Sub Lord", asc_d["sub_lord"])
    ]
    return [{"factor": k, "planet": v} for k, v in rows], longs, asc_d

def calc_chart(jd, lat, lon):
    longs = planet_longitudes(jd)
    asc, cusps = asc_and_cusps(jd, lat, lon)
    planets = {name: point_details(value) for name, value in longs.items()}
    cusp_rows = [{"house": i+1, **point_details(value)} for i, value in enumerate(cusps)]
    return {"ascendant": point_details(asc), "planets": planets, "cusps": cusp_rows}

@app.get("/")
def home():
    return send_from_directory("static", "index.html")


@app.get("/manifest.webmanifest")
def manifest():
    return send_from_directory("static", "manifest.webmanifest", mimetype="application/manifest+json")

@app.get("/service-worker.js")
def service_worker():
    return send_from_directory("static", "service-worker.js", mimetype="application/javascript")

@app.get("/icon-192.png")
def icon_192():
    return send_from_directory("static", "icon-192.png")

@app.get("/icon-512.png")
def icon_512():
    return send_from_directory("static", "icon-512.png")

@app.post("/api/calculate")
def calculate():
    try:
        d = request.get_json(force=True)
        jd = jd_from_local(d["datetime"], d["tz_offset"])
        lat, lon = float(d["latitude"]), float(d["longitude"])
        rp, _, _ = ruling_planets(jd, lat, lon)
        return jsonify({"ruling_planets": rp, "chart": calc_chart(jd, lat, lon)})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.post("/api/btr")
def btr():
    try:
        d = request.get_json(force=True)
        date = d["birth_date"]
        start = datetime.fromisoformat(date + "T" + d["start_time"])
        end = datetime.fromisoformat(date + "T" + d["end_time"])
        if end <= start:
            raise ValueError("समाप्ति समय, प्रारंभ समय के बाद होना चाहिए।")
        lat, lon, tz = float(d["latitude"]), float(d["longitude"]), float(d["tz_offset"])
        ref_jd = jd_from_local(d["reference_datetime"], tz)
        rp_rows, _, _ = ruling_planets(ref_jd, lat, lon)
        rp_set = {x["planet"] for x in rp_rows}
        step = max(1, int(d.get("step_minutes", 1)))
        results = []
        t = start
        while t <= end:
            jd = jd_from_local(t.isoformat(timespec="minutes"), tz)
            asc, _ = asc_and_cusps(jd, lat, lon)
            ad = point_details(asc)
            moon = point_details(planet_longitudes(jd)["Moon"])
            # Transparent heuristic ranking: Ascendant factors carry more weight.
            factors = [
                ("Ascendant Sub Lord", ad["sub_lord"], 3),
                ("Ascendant Star Lord", ad["star_lord"], 2),
                ("Ascendant Sign Lord", ad["sign_lord"], 1),
                ("Moon Sub Lord", moon["sub_lord"], 1),
                ("Moon Star Lord", moon["star_lord"], 1)
            ]
            score = sum(weight for _, planet, weight in factors if planet in rp_set)
            matches = [name for name, planet, _ in factors if planet in rp_set]
            results.append({
                "time": t.strftime("%H:%M"),
                "score": score,
                "max_score": 8,
                "matches": matches,
                "ascendant": ad,
                "rp_match": score / 8.0
            })
            t += timedelta(minutes=step)
        results.sort(key=lambda x: (x["score"], x["time"]), reverse=True)
        return jsonify({
            "method": "Ruling-planet matching heuristic",
            "ruling_planets": rp_rows,
            "top_candidates": results[:10],
            "note": "यह KP Ruling Planets आधारित exploratory ranking है, प्रमाणित/निश्चित जन्म समय नहीं। अंतिम पुष्टि के लिए KP विशेषज्ञ द्वारा चार्ट और नियमों की जाँच आवश्यक है।"
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
